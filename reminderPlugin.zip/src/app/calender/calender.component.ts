import { Component ,ViewChild ,Input, ElementRef,AfterViewInit,OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-calender',
  templateUrl: './calender.component.html',
  styleUrls: ['./calender.component.css']
})
export class CalenderComponent implements AfterViewInit{
  @Input() isTrue:any; 
  tommorrow:number=1;
  dayAfterTomorrow:number=2;
  secondDayAfterTommorrow:number=3;
  now:Date = new Date(); 
  dayOne:Date=new Date();
  dayTwo:Date=new Date();
  dayThree:Date=new Date();
  d1:any=[];
  d2:any=[];
  d3:any=[];
  eventForm = new FormGroup({
    eventName: new FormControl('',Validators.required),
    eventStartDate:new FormControl('',Validators.required),
    eventEndDate:new FormControl('',Validators.required),
    eventStartTime:new FormControl('',Validators.required),
    eventEndTime:new FormControl('',Validators.required),
 });
 timeArray=[
  { id:'9', time:'9am' }, 
  { id:'10', time:'10am' },
  { id:'11', time:'11am' }, 
  { id:'12', time:'12am' }, 
  { id:'13', time:'1pm' },
  { id:'14', time:'2pm' }, 
  { id:'15', time:'3pm' }, 
  { id:'16', time:'4pm' },
  { id:'17', time:'5pm' }, 
]
 data=[ 
  { start: '2018-05-13T09:00:00', end: '2018-05-13T12:00:00', title: 'Event 1' },
  { start: '2018-05-15T09:00:00', end: '2018-05-15T10:00:00', title: 'Event 2' },
  { start: '2018-05-15T12:00:00', end: '2018-05-15T14:00:00', title: 'Event 3' },
  { start: '2018-05-15T16:00:00', end: '2018-05-15T17:00:00', title: 'Event 4' },
  { start: '2018-05-16T11:00:00', end: '2018-05-16T14:00:00', title: 'Event 5' },
  { start: '2018-05-17T10:00:00', end: '2018-05-17T15:00:00', title: 'Event 6' }
]
 addEvent(){
   if(!this.eventForm.valid){
    alert("please fill the form completely");
   }
   else{
    let startDate=this.eventForm.get('eventStartDate').value;
    if(startDate.month<=9){
      startDate.month="0"+startDate.month;
      }
    if(startDate.day<=9){
        startDate.day="0"+startDate.day;
      }
    let endDate=this.eventForm.get('eventEndDate').value;
      if(endDate.month<=9){
        endDate.month="0"+endDate.month;
        }
      if(endDate.day<=9){
          endDate.day="0"+endDate.day;
        }
      let startTime=this.eventForm.get('eventStartTime').value;
      let endTime=this.eventForm.get('eventEndTime').value;
      let start=(startDate.year+"-"+startDate.month+"-"+startDate.day+"T"+startTime+":"+"00"+":"+"00");
      let end=(endDate.year+"-"+endDate.month+"-"+endDate.day+"T"+endTime+":"+"00"+":"+"00");
      let title=this.eventForm.get('eventName').value;
      let data={start,end,title}
      this.data.push(data);
      this.functions(0);
    this.eventForm.reset();
  }
 }
   ngAfterViewInit (){
      this.functions(0);
    }
  functions(data:number){
      this.now.setDate(this.now.getDate()+data)
        this.dayOne=new Date(this.dayOne.setDate(this.now.getDate()+this.tommorrow));
        this.dayTwo=new Date(this.dayTwo.setDate(this.now.getDate()+this.dayAfterTomorrow));
        this.dayThree=new Date(this.dayThree.setDate(this.now.getDate()+this.secondDayAfterTommorrow));
          for(let i=0; i<this.data.length; i++)
          {
            let start= new Date(this.data[i].start)
            if(new Date(this.data[i].start).getDate()==this.dayOne.getDate()){
                this.checkHours(this.data[i],this.d1);
            }
            else if(new Date(this.data[i].start).getDate()==this.dayTwo.getDate()){
                this.checkHours(this.data[i],this.d2);
            }
            else if(new Date(this.data[i].start).getDate()==this.dayThree.getDate()){
                this.checkHours(this.data[i],this.d3);
            }
           else{ 
             continue;
           }
          }
    }
  checkHours(data,events){
    let start=new Date(data.start).getHours();
    let end=new Date(data.end).getHours()
    if(events.length==9){
        events[start-9].title=data.title;
        events[start-9].isTrue="yellow";
    }
    else{
    for(let i=9;i<18;i++)
    {
      if(start==i){            
        events.push({title: data.title, isTrue:"yellow"});
      }
      else{
        events.push({title: "",isTrue:"gray"})
      }
    }  
  }
  for(let i=start-9;i<end-9;i++){
    console.log(events)
      events[i].isTrue="yellow";
    }
  }
  otherDays(data:number){
    this.d1=[];
    this.d2=[];
    this.d3=[];
   this.functions(data);
  } 
}

